//
//  main.m
//  自定义转场动画02
//
//  Created by Dean on 2018/9/9.
//  Copyright © 2018年 tz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
