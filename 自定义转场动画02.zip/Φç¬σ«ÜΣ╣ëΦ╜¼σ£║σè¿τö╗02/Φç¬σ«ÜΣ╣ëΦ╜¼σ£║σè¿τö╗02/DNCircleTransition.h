
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface DNCircleTransition : NSObject<UIViewControllerAnimatedTransitioning>
@property (nonatomic, assign) BOOL isPush;

@end
