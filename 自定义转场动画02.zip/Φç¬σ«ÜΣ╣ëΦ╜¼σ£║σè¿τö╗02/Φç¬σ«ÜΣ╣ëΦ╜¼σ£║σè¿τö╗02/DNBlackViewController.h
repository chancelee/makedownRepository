

#import <UIKit/UIKit.h>

@interface DNBlackViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *redBtn;

@end
